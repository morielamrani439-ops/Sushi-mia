(() => {
  const phoneE164 = "972544298580";
  const $ = (id) => document.getElementById(id);

    // ===== INFO POPUP (first visit) =====
    function openInfo(){
      const m = $("infoModal");
      if(!m) return;
      m.setAttribute("aria-hidden","false");
      document.body.style.overflow="hidden";
    }
    function closeInfo(){
      const m = $("infoModal");
      if(!m) return;
      m.setAttribute("aria-hidden","true");
      document.body.style.overflow="";
      try{ localStorage.setItem("mia_info_seen","1"); }catch(e){}
    }
    function maybeShowInfo(){
      try{ if(localStorage.getItem("mia_info_seen")==="1") return; }catch(e){}
      openInfo();
    }


  // ===== DATA =====
  const MENU = {
    specials: [
      {id:"lime",   name:"ליים רול",   price:45, desc:"אבוקדו, גזר, בצל ירוק ומלפפון, עטוף סלמון נא, פלחי לימון, טריאקי ופאנקו.", img:"assets/lime.jpg"},
      {id:"fire",   name:"פייר רול 🔥", price:45, desc:"אבוקדו, בצל ירוק, בטטה ומלפפון, עטוף סלמון צרוב, פלפל צ׳ילי וספייסי מיונז.", img:"assets/fire.jpg"},
      {id:"crazy",  name:"קרייזי רול", price:50, desc:"סלמון מטוגן, אבוקדו, בצל ירוק ומלפפון, עטוף סלמון צרוב, איולי פסטו ושברי צ׳יפס קריספי.", img:"assets/crazy.jpg"},
      {id:"fried",  name:"פרייד רול",  price:45, desc:"סלמון, אבוקדו, בצל ירוק ובטטה, מטוגן בפנקו קריספי.", img:null},
      {id:"dirty",  name:"דירטי רול",  price:45, desc:"סלמון נא, גזר, בצל ירוק ומלפפון, עטוף אבוקדו, פלחי לימון, ספייסי טריאקי ובטטה קרנץ׳.", img:"assets/dirty.jpg"},
      {id:"peanut", name:"בוטן רול",   price:45, desc:"סלמון מטוגן, שיטאקי, אבוקדו ומלפפון, עטוף בטטה, חמאת בוטנים, טריאקי ובוטנים גרוסים.", img:"assets/peanut.jpg"},
    ],
    starters: [
      {id:"wings",    name:"כנפיים בצ׳ילי", price:30, img:null},
      {id:"eggroll",  name:"אגרול סיני",    price:15, img:null},
      {id:"homefries",name:"הום פרייז",     price:25, img:null},
    ],
    combos: [
      {id:"pair",   name:"הזוגית",         price:220, mode:"choose", specs:4, starts:2, desc:"4 ספיישלים לבחירה + 2 ראשונות"},
      {id:"mia",    name:"קומבינציית מיה", price:77,  mode:"fixed",  desc:"4 יח׳ פייר רול + 4 יח׳ פרייד רול + אגרול"},
      {id:"justice",name:"ליגת הצדק",      price:250, mode:"choose", specs:5, starts:2, desc:"5 ספיישלים + 2 ראשונות"},
      {id:"party8", name:"מגש מסיבה (8 רולים)", price:340, mode:"fixed", desc:"מגש מסיבה 8 רולים"},
    ],
  };

  const BUILDER = {
    bases: [
      // Inside-out (wraps allowed)
      {id:"inside_fish", name:"אינסייד אאוט (דג)", price:40, fish:true,  toppingsMax:2, wraps:true,  toppingsExact:null},
      {id:"inside_veg",  name:"אינסייד אאוט (צמחוני)", price:37, fish:false, toppingsMax:4, wraps:true, toppingsExact:null},

      // Maki (no wraps)
      {id:"maki_fish", name:"מאקי 8 יח׳ (דג)", price:25, fish:true,  toppingsMax:0, wraps:false, toppingsExact:0},
      {id:"maki_veg",  name:"מאקי 8 יח׳ (צמחוני)", price:22, fish:false, toppingsMax:1, wraps:false, toppingsExact:1},

      // Futomaki (no wraps)
      {id:"futo_fish", name:"פוטומאקי 5 יח׳ (דג)", price:40, fish:true,  toppingsMax:3, wraps:false, toppingsExact:null},
      {id:"futo_veg",  name:"פוטומאקי 5 יח׳ (צמחוני)", price:37, fish:false, toppingsMax:4, wraps:false, toppingsExact:null},
    ],
    fishTypes: [
      {id:"salmon_raw",   name:"סלמון נא",     extra:0},
      {id:"salmon_fried", name:"סלמון מטוגן", extra:0},
      {id:"tuna",         name:"טונה",        extra:7},
    ],
    toppings: ["אבוקדו","בצל ירוק","בטטה","מלפפון","גזר","שיטאקי","חמאת בוטנים"],
    wraps: [
      {id:"none",            name:"ללא מעטפת",   price:0},
      {id:"wrap_avocado",    name:"אבוקדו",      price:5},
      {id:"wrap_sweetpotato",name:"בטטה",        price:4},
      {id:"wrap_salmon",     name:"סלמון",       price:12},
      {id:"wrap_salmon_seared", name:"סלמון צרוב", price:12},
      {id:"wrap_tuna",       name:"טונה",        price:15},
            {id:"wrap_peanut",     name:"חמאת בוטנים", price:5},
      {id:"wrap_pecan",      name:"פקאן מתוק",   price:8},
      {id:"wrap_crunch",     name:"בטטה קראנץ׳",  price:6},
      {id:"wrap_panko",      name:"פנקו",        price:3},
      {id:"wrap_fry",        name:"טיגון רול",   price:5},
    ],
  };

  // ===== HELPERS =====
  function fmt(n){ try { return new Intl.NumberFormat("he-IL").format(n); } catch { return String(n); } }
  function esc(s){
    return String(s).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;")
      .replaceAll('"',"&quot;").replaceAll("'","&#039;");
  }
  function waLink(text){ return `https://wa.me/${phoneE164}?text=${encodeURIComponent(text)}`; }

  // ===== WHATSAPP SHORT LINKS =====
  function refreshWaButtons(){
    const msg = "שלום, אני רוצה להזמין מ‑MIA Sushi 🍣";
    const a1 = $("waHeader"); if(a1) a1.href = waLink(msg);
    const a2 = $("waFab");    if(a2) a2.href = waLink(msg);
  }

  // ===== CART =====
  const cart = [];
  function addToCart(name, price, meta){
    const key = name + "|" + price + "|" + JSON.stringify(meta||null);
    const it = cart.find(x=>x.key===key);
    if(it) it.qty += 1;
    else cart.push({key, name, price, qty:1, meta});
    renderCart();
  }
  function totals(){
    const count = cart.reduce((s,i)=>s+i.qty,0);
    const total = cart.reduce((s,i)=>s+i.qty*i.price,0);
    return {count,total};
  }
  function buildOrderText(){
    const phone = ($("custPhone")?.value||"").trim();
    const name = ($("custName")?.value||"").trim();
    const time = ($("pickupTime")?.value||"").trim();
    const note = ($("orderNote")?.value||"").trim();

    const lines = [];
    lines.push("שלום, אני רוצה להזמין מ‑MIA Sushi 🍣");
    lines.push(`טלפון לחזרה: ${phone || "—"}`);
    if(name) lines.push(`שם: ${name}`);
    if(time) lines.push(`שעת איסוף: ${time}`);
    lines.push("");
    lines.push("הזמנה:");
    cart.forEach(it=>{
      lines.push(`- ${it.name} × ${it.qty} (₪${it.price})`);
      if(it.meta?.details) lines.push(`  ${it.meta.details}`);
    });
    const {total} = totals();
    lines.push("");
    lines.push(`סה״כ לתשלום: ₪${total}`);
    if(note){ lines.push(""); lines.push(`הערות: ${note}`); }
    return lines.join("\n");
  }
  function renderCart(){
    const {count,total} = totals();
    const countEl = $("cartCount"); if(countEl) countEl.textContent = String(count);
    const totalEl = $("cartTotal"); if(totalEl) totalEl.textContent = `${fmt(total)}₪`;

    const empty = $("emptyCart");
    const list  = $("cartItems");
    const send  = $("sendOrder");

    if(cart.length===0){
      if(empty) empty.hidden = false;
      if(list){ list.hidden = true; list.innerHTML=""; }
      if(send) send.href = waLink("שלום, אני רוצה להזמין מ‑MIA Sushi 🍣");
      return;
    }

    if(empty) empty.hidden = true;
    if(list) list.hidden = false;

    if(list){
      list.innerHTML = cart.map((it,idx)=>{
        const metaLine = it.meta?.details ? `<div class="cartmeta">${esc(it.meta.details).replaceAll("\n","<br>")}</div>` : "";
        return `
          <div class="cartitem">
            <div>
              <div class="cartname">${esc(it.name)}</div>
              ${metaLine}
              <div class="cartmeta">₪${fmt(it.price)} • כמות: ${it.qty} • סה"כ: ₪${fmt(it.price*it.qty)}</div>
            </div>
            <div class="actions">
              <button class="iconbtn" type="button" data-act="dec" data-idx="${idx}">−</button>
              <div class="qty">${it.qty}</div>
              <button class="iconbtn" type="button" data-act="inc" data-idx="${idx}">+</button>
              <button class="iconbtn" type="button" data-act="del" data-idx="${idx}">✕</button>
            </div>
          </div>
        `;
      }).join("");

      list.querySelectorAll("button[data-act]").forEach(b=>{
        b.addEventListener("click", ()=>{
          const idx = Number(b.getAttribute("data-idx"));
          const act = b.getAttribute("data-act");
          if(!cart[idx]) return;
          if(act==="inc") cart[idx].qty += 1;
          if(act==="dec") cart[idx].qty = Math.max(1, cart[idx].qty - 1);
          if(act==="del") cart.splice(idx,1);
          renderCart();
        });
      });
    }

    if(send) send.href = waLink(buildOrderText());
  }

  // ===== DRAWER (CART) =====
  function openDrawer(){
    const d=$("drawer"); if(!d) return;
    d.setAttribute("aria-hidden","false");
    document.body.style.overflow="hidden";
  }
  function closeDrawer(){
    const d=$("drawer"); if(!d) return;
    d.setAttribute("aria-hidden","true");
    document.body.style.overflow="";
  }

  // ===== MENU MODAL =====
  function openMenu(){
    const m=$("menuModal"); if(!m) return;
    m.setAttribute("aria-hidden","false");
    document.body.style.overflow="hidden";
  }
  function closeMenu(){
    const m=$("menuModal"); if(!m) return;
    m.setAttribute("aria-hidden","true");
    document.body.style.overflow="";
  }

  // ===== CARDS =====
  function cardHTML(item, kind){
    const hasImg = !!item.img;
    const media = (kind==="starter")
      ? ``
      : (hasImg
          ? `<button class="card-media media-btn" type="button" aria-label="פתח תמונה" data-open="1" data-id="${item.id}" data-kind="${kind}"><img src="${item.img}" alt="${esc(item.name)}" loading="lazy"></button>`
          : `<div class="card-media"><div style="font-size:44px">🍣</div></div>`);

    return `
      <div class="card">
        ${media}
        <div class="card-body">
          <div class="card-title">${esc(item.name)}</div>
          <div class="card-row">
            <div class="price">${fmt(item.price)}₪</div>
            <button class="btn btn-primary" type="button" data-kind="${kind}" data-id="${item.id}">הוסף לעגלה</button>
          </div>
        </div>
      </div>
    `;
  }
  function renderGrid(elId, items, kind){
    const el=$(elId); if(!el) return;
    el.innerHTML = items.map(i=>cardHTML(i,kind)).join("");

    // Add to cart buttons
    el.querySelectorAll("button[data-id][data-kind]").forEach(btn=>{
      if(btn.classList.contains("media-btn")) return;
      btn.addEventListener("click", ()=>{
        const id=btn.getAttribute("data-id");
        const it=items.find(x=>x.id===id);
        if(!it) return;
        addToCart(it.name, it.price, null);
        uiAdded();
      });
    });

    // Open product modal on image click (specials only)
    el.querySelectorAll("button.media-btn[data-open='1']").forEach(b=>{
      b.addEventListener("click", ()=>{
        const id=b.getAttribute("data-id");
        const it=items.find(x=>x.id===id);
        if(!it || !it.img) return;
        openProduct(it);
      });
    });
  }

  // ===== COMBOS =====
  function renderCombos(){
    const el=$("combosGrid"); if(!el) return;
    el.innerHTML = MENU.combos.map(c=>{
      const media = `<div class="card-media"><div style="font-size:44px">🥢</div></div>`;
      const actionLabel = c.mode==="fixed" ? "הוסף לעגלה" : "בחר קומבינציה";
      const actionClass = c.mode==="fixed" ? "btn-primary" : "btn-ghost";
      return `
        <div class="card">
          ${media}
          <div class="card-body">
            <div class="card-title">${esc(c.name)}</div>
            <div class="card-desc">${esc(c.desc)}</div>
            <div class="card-row">
              <div class="price">${fmt(c.price)}₪</div>
              <button class="btn ${actionClass}" type="button" data-combo="${c.id}">${actionLabel}</button>
            </div>
          </div>
        </div>
      `;
    }).join("");

    el.querySelectorAll("button[data-combo]").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        const id=btn.getAttribute("data-combo");
        const c=MENU.combos.find(x=>x.id===id);
        if(!c) return;

        if(c.mode==="fixed"){
          addToCart(c.name, c.price, {details:c.desc});
          uiAdded();
        } else {
          openCombo(c);
        }
      });
    });
  }

  let activeCombo=null;
  let selSpecs=new Set();
  let selStarts=new Set();

  function chip(label, id){
    return `<div class="chip" role="button" tabindex="0" data-id="${id}" data-on="0">${esc(label)}</div>`;
  }
  
function updateComboCounters(){
    if(!activeCombo) return;
    const sFilled = selSpecs.filter(Boolean).length;
    const stFilled = selStarts.filter(Boolean).length;
    $("specCounter").textContent = `(${sFilled}/${activeCombo.specs})`;
    $("startCounter").textContent = `(${stFilled}/${activeCombo.starts})`;
  }

  function buildSelectRow(kind, idx){
    const list = kind==="spec" ? MENU.specials : MENU.starters;
    const label = kind==="spec" ? `ספיישל ${idx+1}` : `ראשונה ${idx+1}`;
    const options = ['<option value="">בחר…</option>']
      .concat(list.map(x=>`<option value="${x.id}">${esc(x.name)}</option>`))
      .join("");
    return `
      <label class="selrow">
        <span class="muted">${label}</span>
        <select class="select" data-kind="${kind}" data-idx="${idx}">${options}</select>
      </label>
    `;
  }

  function openCombo(combo){
    activeCombo=combo;
    selSpecs = Array(combo.specs).fill("");
    selStarts = Array(combo.starts).fill("");

    $("comboTitle").textContent = combo.name;
    $("comboSub").textContent = `בחר ${combo.specs} ספיישלים ו‑${combo.starts} ראשונות ואז לחץ “הוסף קומבינציה לעגלה”.`;

    const specWrap=$("specChips");
    const startWrap=$("startChips");
    specWrap.innerHTML = Array.from({length: combo.specs}, (_,i)=>buildSelectRow("spec", i)).join("");
    startWrap.innerHTML = Array.from({length: combo.starts}, (_,i)=>buildSelectRow("start", i)).join("");

    const bind=(wrap)=>{
      wrap.querySelectorAll("select[data-kind]").forEach(sel=>{
        sel.addEventListener("change", ()=>{
          const kind = sel.getAttribute("data-kind");
          const idx = parseInt(sel.getAttribute("data-idx"),10);
          const val = sel.value || "";
          if(kind==="spec") selSpecs[idx]=val;
          else selStarts[idx]=val;
          updateComboCounters();
        });
      });
    };
    bind(specWrap);
    bind(startWrap);

    $("comboPanel").hidden=false;
    updateComboCounters();
    $("comboPanel").scrollIntoView({behavior:"smooth", block:"start"});
  }

  function closeCombo(){ $("comboPanel").hidden=true; activeCombo=null; }
  function clearCombo(){ if(activeCombo) openCombo(activeCombo); }

  function addCombo(){
    if(!activeCombo) return;
    const sFilled = selSpecs.filter(Boolean).length;
    const stFilled = selStarts.filter(Boolean).length;
    if(sFilled!==activeCombo.specs || stFilled!==activeCombo.starts){
      alert("בחר בדיוק לפי הכמות הנדרשת כדי להוסיף לעגלה.");
      return;
    }

    const specs = selSpecs.map(id=>MENU.specials.find(s=>s.id===id)?.name).filter(Boolean);
    const starts = selStarts.map(id=>MENU.starters.find(s=>s.id===id)?.name).filter(Boolean);

    const details = `ספיישלים: ${specs.join(" • ")}\nראשונות: ${starts.join(" • ")}`;
    addToCart(`${activeCombo.name} (בחירה)`, activeCombo.price, {details});
    uiAdded();
    closeCombo();
  }




  function fillSelect(el, items, mapFn){ el.innerHTML = items.map(mapFn).join(""); }
  function currentBase(){ return BUILDER.bases.find(b=>b.id===$("bBase").value) || BUILDER.bases[0]; }

  function syncBuilderUI(){
    const base=currentBase();

    // fish select
    const fishSel=$("bFishType");
    fishSel.disabled = !base.fish;

    // wrap select
    const wrapSel=$("bWrap");
    wrapSel.disabled = !base.wraps;
    if(!base.wraps) wrapSel.value="none";

    // toppings hint
    const hint=$("toppingHint");
    if(base.toppingsExact===1){
      hint.textContent = "חובה לבחור תוספת אחת.";
    } else if(base.toppingsMax===0){
      hint.textContent = "אין תוספות לבחירה.";
    } else {
      hint.textContent = `בחר עד ${base.toppingsMax} תוספות.`;
    }

    // enforce topping limits/exact
    const max = base.toppingsMax;
    if(base.toppingsExact===0){
      state.toppings.clear();
    }
    if(base.toppingsExact===1 && state.toppings.size>1){
      state.toppings = new Set([...[...state.toppings][0]]);
    }
    if(state.toppings.size>max){
      state.toppings = new Set([...state.toppings].slice(0,max));
    }

    // reflect chips
    $("toppingChips").querySelectorAll(".chip").forEach(c=>{
      const id=c.getAttribute("data-id");
      c.setAttribute("data-on", state.toppings.has(id) ? "1" : "0");
    });

    calcPrice();
  }

  function calcPrice(){
    const base=currentBase();
    const fish = BUILDER.fishTypes.find(f=>f.id===$("bFishType").value) || BUILDER.fishTypes[0];
    const wrap = BUILDER.wraps.find(w=>w.id===$("bWrap").value) || BUILDER.wraps[0];

    let price = base.price;
    if(base.fish){
      price += fish.extra; // tuna +7 only
    }
    if(base.wraps){
      price += wrap.price;
    }
    $("buildPrice").textContent = String(price);
    return {price, base, fish, wrap};
  }

  function renderBuilder(){
    fillSelect($("bBase"), BUILDER.bases, b=>`<option value="${b.id}">${esc(b.name)} • ${b.price}₪</option>`);
    fillSelect($("bFishType"), BUILDER.fishTypes, f=>`<option value="${f.id}">${esc(f.name)}${f.extra?` +${f.extra}₪`:``}</option>`);
    fillSelect($("bWrap"), BUILDER.wraps, w=>`<option value="${w.id}">${esc(w.name)}${w.price?` +${w.price}₪`:``}</option>`);

    const chips=$("toppingChips");
    chips.innerHTML = BUILDER.toppings.map(t=>`<div class="chip" data-id="${esc(t)}" data-on="0">${esc(t)}</div>`).join("");

    chips.querySelectorAll(".chip").forEach(c=>{
      c.addEventListener("click", ()=>{
        const base=currentBase();
        const id=c.getAttribute("data-id");
        const on=c.getAttribute("data-on")==="1";

        if(base.toppingsMax===0) return;

        if(on){
          state.toppings.delete(id);
          c.setAttribute("data-on","0");
        } else {
          if(base.toppingsExact===1){
            // keep exactly one: clear others
            state.toppings.clear();
            chips.querySelectorAll(".chip").forEach(x=>x.setAttribute("data-on","0"));
            state.toppings.add(id);
            c.setAttribute("data-on","1");
          } else {
            if(state.toppings.size>=base.toppingsMax) return;
            state.toppings.add(id);
            c.setAttribute("data-on","1");
          }
        }
        calcPrice();
      });
    });

    $("bBase").addEventListener("change", syncBuilderUI);
    $("bFishType").addEventListener("change", calcPrice);
    $("bWrap").addEventListener("change", calcPrice);

    $("addBuild").addEventListener("click", ()=>{
      const {price, base, fish, wrap} = calcPrice();
      const tops=[...state.toppings];

      // validations
      if(base.toppingsExact===1 && tops.length!==1){
        alert("חייב לבחור תוספת אחת.");
        return;
      }

      const parts=[base.name];

      if(base.fish){
        parts.push(fish.name);
      }

      if(base.toppingsMax>0){
        if(tops.length) parts.push(`תוספות: ${tops.join(", ")}`);
        else if(base.toppingsExact===1) { /* handled above */ }
      }

      if(base.wraps && wrap.price>0){
        parts.push(`מעטפת: ${wrap.name}`);
      }

      addToCart(`הרכבה אישית`, price, {details: parts.join(" • ")});
      uiAdded();
    });

    syncBuilderUI();
  }

  
  // ===== UX (toast + cart pop) =====
  function uiAdded(){
    const cartBtn = $("openCart");
    if(cartBtn){
      cartBtn.classList.remove("fab-pop");
      // reflow
      void cartBtn.offsetWidth;
      cartBtn.classList.add("fab-pop");
    }
    const t = $("toast");
    if(t){
      t.setAttribute("aria-hidden","false");
      setTimeout(()=>t.setAttribute("aria-hidden","true"), 1200);
    }
  }

  // ===== PRODUCT MODAL =====
  let activeProduct = null;
  function openProduct(p){
    activeProduct = p;
    $("productTitle").textContent = p.name;
    $("productImg").src = p.img;
    $("productImg").alt = p.name;
    if($("productDesc") && p.desc){ $("productDesc").textContent=p.desc; }
$("productPrice").textContent = `${fmt(p.price)}₪`;
    const m = $("productModal");
    m.setAttribute("aria-hidden","false");
    document.body.style.overflow="hidden";
  }
  function closeProduct(){
    const m = $("productModal");
    if(!m) return;
    m.setAttribute("aria-hidden","true");
    document.body.style.overflow="";
    activeProduct = null;
  }

    // ===== ORDER TIME WINDOW =====
  function isOrderAllowedTime(){
    const now = new Date();
    const hour = now.getHours();
    // allowed: 12:00 - 22:59
    if(hour < 12 || hour >= 22){
      alert("הזמנות באתר פתוחות בין 12:00 ל‑22:00. נשמח לראותכם בזמן הזה 🍣");
      return false;
    }
    return true;
  }

// ===== VALIDATION =====
  function normalizePhone(raw){
    return String(raw||"").replace(/[^0-9+]/g,"").trim();
  }
  function validatePhoneOrBlock(){
    const raw = $("custPhone")?.value || "";
    const phone = normalizePhone(raw);
    // basic: require at least 9 digits
    const digits = phone.replace(/[^0-9]/g,"");
    if(digits.length < 9){
      alert("חייב למלא מספר טלפון לחזרה כדי לשלוח הזמנה.");
      $("custPhone")?.focus();
      return null;
    }
    return phone;
  }

  
  // ===== CONFIRM ORDER MODAL =====
  let pendingOrderText = "";
  function openConfirm(text){
    pendingOrderText = text || "";
    const m = $("confirmModal");
    if(!m) return;
    $("confirmText").textContent = pendingOrderText;
    m.setAttribute("aria-hidden","false");
    document.body.style.overflow="hidden";
  }
  function closeConfirm(){
    const m = $("confirmModal");
    if(!m) return;
    m.setAttribute("aria-hidden","true");
    document.body.style.overflow="";
    pendingOrderText = "";
  }

  // ===== BIND UI =====
  function bindUI(){
    // info popup
    $("infoClose")?.addEventListener("click", closeInfo);
    $("infoBackdrop")?.addEventListener("click", closeInfo);
    $("infoOk")?.addEventListener("click", closeInfo);

    $("openCart")?.addEventListener("click", openDrawer);
    $("closeCart")?.addEventListener("click", closeDrawer);
    $("drawerBackdrop")?.addEventListener("click", closeDrawer);

    $("clearCart")?.addEventListener("click", ()=>{
      cart.length=0; renderCart();
    });

    ["custPhone","custName","pickupTime","orderNote"].forEach(id=>{
      $(id)?.addEventListener("input", ()=>{ $("sendOrder").href = waLink(buildOrderText()); });
    });

    // Prevent sending without phone
    $("sendOrder")?.addEventListener("click", (e)=>{
      e.preventDefault();
      if(!isOrderAllowedTime()) return;
      const ok = validatePhoneOrBlock();
      if(!ok) return;
      const text = buildOrderText();
      openConfirm(text);
    });

    $("openMenu")?.addEventListener("click", openMenu);
    $("closeMenu")?.addEventListener("click", closeMenu);
    $("menuBackdrop")?.addEventListener("click", closeMenu);

    $("comboClose")?.addEventListener("click", closeCombo);
    $("comboClear")?.addEventListener("click", clearCombo);
    $("comboAdd")?.addEventListener("click", addCombo);
  }


  // ===== DELEGATED MODAL HANDLERS (fallback) =====
  document.addEventListener("click", (e)=>{
    const t = e.target;
    // Confirm modal
    if(t && (t.id==="confirmClose" || t.id==="confirmCancel" || t.id==="confirmBackdrop")){
      e.preventDefault();
      closeConfirm();
    }
    if(t && t.id==="confirmSend"){
      e.preventDefault();
      if(!isOrderAllowedTime()) return;
      if(!pendingOrderText){ closeConfirm(); return; }
      const link = waLink(pendingOrderText);
      closeConfirm();
      window.location.href = link;
    }
    // Product modal
    if(t && t.id==="productAdd"){
      e.preventDefault();
      if(!activeProduct) return;
      addToCart(activeProduct.name, activeProduct.price, null);
      uiAdded();
      closeProduct();
    }

    if(t && (t.id==="closeProduct" || t.id==="productBackdrop")){
      e.preventDefault();
      closeProduct();
    }
  });

  // ===== INIT =====
  refreshWaButtons();
  maybeShowInfo();
  renderGrid("specialsGrid", MENU.specials, "special");
  renderGrid("startersGrid", MENU.starters.concat(MENU.party||[]), "starter");
  renderCombos();
  renderBuilder();
  bindUI();
  renderCart();
})();